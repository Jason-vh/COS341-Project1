# COS341 Project 1
-------
> Writing a lexer for the language SPL (Students Programming Language). This is Project 1(a) for COS 341 - Compiler Construction.


Group Members:
- Jason van Hattum
- Marthinus Richter
