package Tokens;

public class IO extends Token {
    public IO(String v) {
        super(v);
    }
}
