package Tokens;

public class Procedure extends Token{
    public Procedure(String v) {
        super(v);
    }
}
