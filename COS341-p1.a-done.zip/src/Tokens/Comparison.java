package Tokens;

public class Comparison extends Token {
	public Comparison(String value){
		super(value);
	}
}
