package Tokens;

public class ShortString extends Token {
	public ShortString(String s){
		super(s);
	}
}
