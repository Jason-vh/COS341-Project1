package Tokens;

public class ControlStructure extends Token {
    public ControlStructure(String value) {
        super(value);
    }
}
