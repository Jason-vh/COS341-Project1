package Tokens;

public class Halt extends Token {
    public Halt(String value) {
        super(value);
    }
}
