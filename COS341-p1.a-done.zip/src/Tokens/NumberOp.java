package Tokens;

public class NumberOp extends Token {
    public NumberOp(String value) {
        super(value);
    }
}
