package Tokens;

public class Integer extends Token {
    public Integer(String v) {
        super(v);
    }
}
