package Tokens;

public class Grouping extends Token {
    public Grouping(String v) {
        super(v);
    }
}
