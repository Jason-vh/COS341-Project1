package Tokens;

public class Variable extends Token {
	public Variable(String s){
		super(s);
	}
}
