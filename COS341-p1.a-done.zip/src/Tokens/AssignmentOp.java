package Tokens;

public class AssignmentOp extends Token {
    public AssignmentOp(String s){
        super(s);
    }
}
