package Tokens;

public class TestToken extends Token {
	public TestToken(String s){
		super(s);
	}
}
