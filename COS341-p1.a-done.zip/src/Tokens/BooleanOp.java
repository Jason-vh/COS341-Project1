package Tokens;

public class BooleanOp extends Token {
	public BooleanOp(String s){
		super(s);
	}
}
