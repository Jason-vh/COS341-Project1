
public class Comparison extends Token{
	Comparison(String value){
		super(value);
	}
}
